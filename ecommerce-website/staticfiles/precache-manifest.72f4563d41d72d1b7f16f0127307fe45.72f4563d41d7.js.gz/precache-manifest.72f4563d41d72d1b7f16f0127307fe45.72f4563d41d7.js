self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b959bfe0090cbee805f0be7b9180e4c1",
    "url": "/static/../index.html"
  },
  {
    "revision": "49db94070563625dad4d",
    "url": "/static/0.5682b10376a5de638dbf.js"
  },
  {
    "revision": "813f9d6be4475258a626aff2f8d169b9",
    "url": "/static/0.5682b10376a5de638dbf.js.gz"
  },
  {
    "revision": "045f5419518524b3bb4d",
    "url": "/static/1.7169664f93ed15c18aeb.js"
  },
  {
    "revision": "3ea7303159699b504dd00d866fc2baf3",
    "url": "/static/1.7169664f93ed15c18aeb.js.gz"
  },
  {
    "revision": "4d400d2202adf32f4125",
    "url": "/static/10.ad2dbb21f8193aa7611f.js"
  },
  {
    "revision": "6d45afa5da50da9592ef5c63c045a581",
    "url": "/static/10.ad2dbb21f8193aa7611f.js.gz"
  },
  {
    "revision": "59cf05e8ccae89996abd",
    "url": "/static/11.b61e3147e175596025ba.js"
  },
  {
    "revision": "51ee88ffdab056b7ff6499188bc03266",
    "url": "/static/11.b61e3147e175596025ba.js.gz"
  },
  {
    "revision": "d2282353125173f0c3c4",
    "url": "/static/12.206d7391b4a164cb2290.js"
  },
  {
    "revision": "3e6defff0a3240e8ebac3ebd2fb8cbdd",
    "url": "/static/12.206d7391b4a164cb2290.js.gz"
  },
  {
    "revision": "390706d6136cc3122d71",
    "url": "/static/13.8cf72846db76b8779a4a.js"
  },
  {
    "revision": "ac67db28eba2346ad31a404dea0e5813",
    "url": "/static/13.8cf72846db76b8779a4a.js.gz"
  },
  {
    "revision": "252a57475ce814125f62",
    "url": "/static/14.282352511f370c7967ef.js"
  },
  {
    "revision": "6308c46dda4ffcf3f899781b9ef15952",
    "url": "/static/14.282352511f370c7967ef.js.gz"
  },
  {
    "revision": "1c1a59c879d94109d29e",
    "url": "/static/15.3bce5b4518563f2cff47.js"
  },
  {
    "revision": "dfef06f1b276a2be42212d76bba1394c",
    "url": "/static/15.3bce5b4518563f2cff47.js.gz"
  },
  {
    "revision": "78902aa2dbc0c9a175a5",
    "url": "/static/16.a2bed35cef352dd09e69.js"
  },
  {
    "revision": "95594cb812b7f4ef117a2a263e38fcf8",
    "url": "/static/16.a2bed35cef352dd09e69.js.gz"
  },
  {
    "revision": "605bb43dff0324b26ab1",
    "url": "/static/17.a75ed2c105b3a6f7f9c5.js"
  },
  {
    "revision": "bac64c52c6d27a37053cb788851d8834",
    "url": "/static/17.a75ed2c105b3a6f7f9c5.js.gz"
  },
  {
    "revision": "ad924577ff4272ceab57",
    "url": "/static/18.2b6699a0c2fc37e0f87a.js"
  },
  {
    "revision": "a6ab1917e9bcb84e492df27664eb2061",
    "url": "/static/18.2b6699a0c2fc37e0f87a.js.gz"
  },
  {
    "revision": "663e09306c633c259547",
    "url": "/static/19.f51c4a09facc8ffd7d87.js"
  },
  {
    "revision": "854ee60c3f1d9017c24b0c3e082895d0",
    "url": "/static/19.f51c4a09facc8ffd7d87.js.gz"
  },
  {
    "revision": "5c7ec4f0d9e32bf19615",
    "url": "/static/2.c8697476f4bd0ac394c8.js"
  },
  {
    "revision": "bbeefdf8ae78498f55cc4b2a4296306b",
    "url": "/static/2.c8697476f4bd0ac394c8.js.gz"
  },
  {
    "revision": "53666d7818be0c38c633",
    "url": "/static/3.250ef04af4d0d5b7dde7.js"
  },
  {
    "revision": "38d306061e2e819982989adcbe43eada",
    "url": "/static/3.250ef04af4d0d5b7dde7.js.gz"
  },
  {
    "revision": "cf433523c36560ce4fd3",
    "url": "/static/4.a5571cc73c29d27dcb97.js"
  },
  {
    "revision": "5c8311196f74e41a420236ff0428e3b5",
    "url": "/static/4.a5571cc73c29d27dcb97.js.gz"
  },
  {
    "revision": "408bca7d17de95a6c7d5",
    "url": "/static/5.7f2b963461cb16843b75.js"
  },
  {
    "revision": "d5bd5409a1dac750744f5e861a328e28",
    "url": "/static/5.7f2b963461cb16843b75.js.gz"
  },
  {
    "revision": "d0706403e4fa355a382f",
    "url": "/static/6.b45d9499a8117b6945b0.js"
  },
  {
    "revision": "f663613a65cb00aa463d1f62e2a5e8c7",
    "url": "/static/6.b45d9499a8117b6945b0.js.gz"
  },
  {
    "revision": "c6d63ea1b522317acc208739901e57e4",
    "url": "/static/61e23af91edcfab286865421479f2394.png"
  },
  {
    "revision": "5a3ee9135ef51f5a8a3e",
    "url": "/static/7.a217bafe2c1a1d76a345.js"
  },
  {
    "revision": "25f234173cf84679f9afce95172f721c",
    "url": "/static/7.a217bafe2c1a1d76a345.js.gz"
  },
  {
    "revision": "eb69bb398db5676b7f89",
    "url": "/static/8.4847d2525b832f9c72a2.js"
  },
  {
    "revision": "5fc95098abc167bc737dd8980e4b3f80",
    "url": "/static/8.4847d2525b832f9c72a2.js.gz"
  },
  {
    "revision": "8cf17fb497abdda5e2cb",
    "url": "/static/9.a1e67f6137e09ad24f6d.js"
  },
  {
    "revision": "aa36d0bf12d533c461fcc02211742508",
    "url": "/static/9.a1e67f6137e09ad24f6d.js.gz"
  },
  {
    "revision": "24268ec63eaa47030479",
    "url": "/static/addresses.20ad6ba60897f209a5ae.js"
  },
  {
    "revision": "52f28327b6b36d8d99da4aaa439db47f",
    "url": "/static/addresses.20ad6ba60897f209a5ae.js.gz"
  },
  {
    "revision": "06017147c5b744044616",
    "url": "/static/addresses~order.275f89d0639316e550f6.js"
  },
  {
    "revision": "c645e78c342d268d8d2689b0a920aea6",
    "url": "/static/addresses~order.275f89d0639316e550f6.js.gz"
  },
  {
    "revision": "2fcd425cb85f6836130d",
    "url": "/static/cart.b0bd97e1133d4ac62e14.js"
  },
  {
    "revision": "dac30282dd4374db2abe03434ae6271f",
    "url": "/static/cart.b0bd97e1133d4ac62e14.js.gz"
  },
  {
    "revision": "def390bd422b942142b7",
    "url": "/static/cart~order~orders-detail.9a1d9f1c3d32bd9c4496.js"
  },
  {
    "revision": "2d8506d61436b9f7c252efd1c231cb60",
    "url": "/static/cart~order~orders-detail.9a1d9f1c3d32bd9c4496.js.gz"
  },
  {
    "revision": "4cfe537d44def3b8693c",
    "url": "/static/change-password.f525dae0a68eb0d545d0.js"
  },
  {
    "revision": "dcadf8593bca1eb8e8e86733ef848592",
    "url": "/static/change-password.f525dae0a68eb0d545d0.js.gz"
  },
  {
    "revision": "39815994d1c41f0f92d0",
    "url": "/static/favorite-products.342da87d2d07e48e0c85.js"
  },
  {
    "revision": "af09300be725d975648b38a46c1d9406",
    "url": "/static/favorite-products.342da87d2d07e48e0c85.js.gz"
  },
  {
    "revision": "4654282770844782486aec16ae5c5479",
    "url": "/static/fca23fd6b994dac7389c7d59cb8767b7.jpg"
  },
  {
    "revision": "0e176033732bf2974130",
    "url": "/static/login.b1f14ed2633ab1218451.js"
  },
  {
    "revision": "6ef7066cf8ec944a46225262f709141b",
    "url": "/static/login.b1f14ed2633ab1218451.js.gz"
  },
  {
    "revision": "a1f7f1d96e6109677740",
    "url": "/static/logout.547b0c2c9e2b054c879a.js"
  },
  {
    "revision": "9730298b33abc764090e3d259053dfc3",
    "url": "/static/logout.547b0c2c9e2b054c879a.js.gz"
  },
  {
    "revision": "ccf8a3168baed955451f",
    "url": "/static/main.e87d32703f734127a0df.js"
  },
  {
    "revision": "643552b7baad3c02e26f5a8faa4b1c29",
    "url": "/static/main.e87d32703f734127a0df.js.gz"
  },
  {
    "revision": "41bc43d944099bc135b3",
    "url": "/static/order.e18413d1dfbc0f55c183.js"
  },
  {
    "revision": "7a4c52fcad3b55026b7c6b3c17bd6fa9",
    "url": "/static/order.e18413d1dfbc0f55c183.js.gz"
  },
  {
    "revision": "3cc12dcdfbc6be831da6",
    "url": "/static/orders-detail.5ee44df98f896532c8ab.js"
  },
  {
    "revision": "c898c3d8a049717144009beb9951aa8c",
    "url": "/static/orders-detail.5ee44df98f896532c8ab.js.gz"
  },
  {
    "revision": "3652b78da9bcd78cfeca",
    "url": "/static/orders-detail~orders-history.56c7e3426f60b75997e4.js"
  },
  {
    "revision": "f45a6ac58a431d42fa39953727668b02",
    "url": "/static/orders-detail~orders-history.56c7e3426f60b75997e4.js.gz"
  },
  {
    "revision": "7579d7ee513e1418013b",
    "url": "/static/orders-history.ca3f8efdafcc1b3ace38.js"
  },
  {
    "revision": "c1386540c3e7a9e54bd39e1b65b191d1",
    "url": "/static/orders-history.ca3f8efdafcc1b3ace38.js.gz"
  },
  {
    "revision": "fff06b4d79a8214a5cc7",
    "url": "/static/personal-info-edit.dded0597bcdf2d04383e.js"
  },
  {
    "revision": "6f7e0d27c58cea20c6c250a012ff7da7",
    "url": "/static/personal-info-edit.dded0597bcdf2d04383e.js.gz"
  },
  {
    "revision": "2061d46a3fafab0cdfb4",
    "url": "/static/personal-info.5a64bc4cf18af2a830b9.js"
  },
  {
    "revision": "ed74c248f08e07e3f7914cdd5b562b19",
    "url": "/static/personal-info.5a64bc4cf18af2a830b9.js.gz"
  },
  {
    "revision": "286fae611b3b0753398c",
    "url": "/static/products-detail.5282ba093d02f9f628a2.js"
  },
  {
    "revision": "f656495d4d74e666a30656e11bf80fa5",
    "url": "/static/products-detail.5282ba093d02f9f628a2.js.gz"
  },
  {
    "revision": "fa9051a468aacd493a50",
    "url": "/static/products.83af946990aa2d09bb9d.js"
  },
  {
    "revision": "2c86086fb83ef531de82c5cc9b4cc09c",
    "url": "/static/products.83af946990aa2d09bb9d.js.gz"
  },
  {
    "revision": "9081d50c211a10e7d550",
    "url": "/static/profile.096316e49825a02be885.js"
  },
  {
    "revision": "a3e81c6269578873f36fe454a0555f86",
    "url": "/static/profile.096316e49825a02be885.js.gz"
  },
  {
    "revision": "ebcc5aa5c5a53da313f5",
    "url": "/static/register.a90bcba470c0412c943b.js"
  },
  {
    "revision": "952f0af96ba0a47ae1074905d2bbd5d1",
    "url": "/static/register.a90bcba470c0412c943b.js.gz"
  },
  {
    "revision": "f7d2383c5db611054d29",
    "url": "/static/vendors~addresses.7f20cc70d6c886d9c73b.js"
  },
  {
    "revision": "002a950a50a3aa3fe324a68fb07060f0",
    "url": "/static/vendors~addresses.7f20cc70d6c886d9c73b.js.gz"
  },
  {
    "revision": "8884a207f919938fb03d",
    "url": "/static/vendors~cart.3c2b546ea393d924957c.js"
  },
  {
    "revision": "ee3e20f903a56a2beca1bd849645f08f",
    "url": "/static/vendors~cart.3c2b546ea393d924957c.js.gz"
  },
  {
    "revision": "2174094001c23203b2e2",
    "url": "/static/vendors~change-password~login~register.25f2a800d2733bc02d2c.js"
  },
  {
    "revision": "f2e28ef469192d27dab3008f07884ef3",
    "url": "/static/vendors~change-password~login~register.25f2a800d2733bc02d2c.js.gz"
  },
  {
    "revision": "55d566fadf13ce38470c",
    "url": "/static/vendors~login~register.391b3894806460cf835b.js"
  },
  {
    "revision": "1a0b5e82fecc9976212305791a31836b",
    "url": "/static/vendors~login~register.391b3894806460cf835b.js.gz"
  },
  {
    "revision": "86709e1e48c12c0df813",
    "url": "/static/vendors~order.f28031faf385a6f74306.js"
  },
  {
    "revision": "d66de1b44ca35dfe240c1bbc3cacb392",
    "url": "/static/vendors~order.f28031faf385a6f74306.js.gz"
  },
  {
    "revision": "7c4fd253213348e0c0d5",
    "url": "/static/vendors~orders-detail~orders-history.4aae044bb0ffe4fc77a9.js"
  },
  {
    "revision": "c4218bb62375c0ed2b9263db2d15be4a",
    "url": "/static/vendors~orders-detail~orders-history.4aae044bb0ffe4fc77a9.js.gz"
  },
  {
    "revision": "57d64cfe85381ee1c4a5",
    "url": "/static/vendors~orders-detail~products-detail.77cebcbc7b5c27153395.js"
  },
  {
    "revision": "2546d65156609cc7802f7eee3571c1c8",
    "url": "/static/vendors~orders-detail~products-detail.77cebcbc7b5c27153395.js.gz"
  },
  {
    "revision": "0c4f2e5e2e84978dd3a3",
    "url": "/static/vendors~products-detail.fc6f9f02ffba969cbc73.js"
  },
  {
    "revision": "043b41fba8ef354b1f946049c7da6dfc",
    "url": "/static/vendors~products-detail.fc6f9f02ffba969cbc73.js.gz"
  },
  {
    "revision": "379eb6e2fa3c24650246",
    "url": "/static/vendors~register.c69ae67a75c780c058de.js"
  },
  {
    "revision": "9b79320d740390425cd84a279faef06a",
    "url": "/static/vendors~register.c69ae67a75c780c058de.js.gz"
  }
]);